# Quake-VS2015
Publication of the Visual Studio 2015 Build of Quake

Just a single note to make. Visual Studio 2015 will attempt to build in x64 mode by default, but we are set up to build in x86 mode (or Win32 for previous versions of Visual Studio).

At the top of the Visual Studio window, if you see x64 in a drop down box, change it to x86 or Win32, whichever your version uses. Then build, and everything will compile.

Finally, you need the Id1 folder from a legitimate version of Quake (or shareware, or a mod if you have a mod that uses an unmodified Quake engine). The easiest thing to do is just buy Quake on Steam.

Goto my YouTube channel at http://youtube.com/philipbuuck or http://handmadequake.org for more information on the Handmade Quake project.

Happy hunting!
Philip Buuck
